exports.commoncontroller = async(req,res,next)=>{

}