const express = require('express')
const route = express.Router()
const commoncontroller = require('../controller/commoncontroller')
route.get('',)
module.exports = route